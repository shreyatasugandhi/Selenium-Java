package TestAutomation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WorkingWithChromeBrowser {

	public static void main(String[] args) {

		//###### Working with Chrome Browser #####
//		//Path to the folder where you have extracted the IEDriverServer executable
//		String service = "D:\\Softwares\\Selenium\\SeleniumDrivers\\chromedriver.exe";
//		System.setProperty("webdriver.chrome.driver", service);
//		
		//initiate webdriver
		WebDriver driver = new ChromeDriver();

		// open url
		driver.get("http://newtours.demoaut.com/");	


	}

}
