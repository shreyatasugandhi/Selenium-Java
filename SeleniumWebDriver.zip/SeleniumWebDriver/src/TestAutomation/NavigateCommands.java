package TestAutomation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class NavigateCommands {

	public static void main(String[] args) {
		
		// Create instance of firefox driver
		WebDriver driver = new FirefoxDriver();
		
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		
		//Open url
		driver.get("http://newtours.demoaut.com/");
		
		//######### Navigate Commands ##########
		   //navigate to the url
		     driver.navigate().to("https://www.facebook.com/");	     
		    
		     String text = driver.getTitle();
		     System.out.println(text);
		     
		   //navigate backward in browser
		     driver.navigate().back();
		     
		     //navigate forward in browser
		     driver.navigate().forward();
		     
		   //refresh the page
		     driver.navigate().refresh();
		     
		     //Close browser and destroy the driver instance
		     driver.close();
		     driver.quit();



	}

}
