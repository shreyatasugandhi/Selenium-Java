package TestAutomation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class WrokingWithIEBrowsers {

	public static void main(String[] args) {
		
//		//Path to the folder where you have extracted the IEDriverServer executable
//		String service = "D:\\Softwares\\Selenium\\SeleniumDrivers\\IEDriverServer.exe";
//		
//		//String service = "C:\\SeleniumDrivers\\IEDriverServer.exe";
//		System.setProperty("webdriver.ie.driver", service);
//		
		
		InternetExplorerDriver  driver = new InternetExplorerDriver();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		// open url
		driver.get("http://newtours.demoaut.com/");	
		
		
		//Enter username
		WebElement username = driver.findElement(By.name("userName"));
		username.clear();
		username.sendKeys("tutorial");
		
		//Enter password
		WebElement password = driver.findElement(By.name("password"));
		password.clear();
		password.sendKeys("tutorial");
		
		//click on sign-in button
		driver.findElement(By.name("login")).click();
		
		
		


	}

}
