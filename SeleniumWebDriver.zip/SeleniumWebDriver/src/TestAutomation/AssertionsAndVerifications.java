package TestAutomation;

import static org.testng.Assert.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AssertionsAndVerifications {

	public static void main(String[] args) {
	//Create instance of WebDriver
	WebDriver driver = new FirefoxDriver();
	
	//Open url into browser
	driver.get("http://newtours.demoaut.com/");

	//######### Assertion #################
	String expectedTitle = "Welcome: Mercury Tours";
	assertEquals(driver.getTitle(), expectedTitle);
	
	
	
//	// Either
//	WebElement element = driver.findElement(By.name("userName"));
//	
//	String texterror = element.getText();
//	assertEquals(actual, expected);
	
//	//Or
//	
//	assertEquals(
//		driver.findElement(By.cssSelector("div._4rbf._53ij")).getText(),
//		"The email or phone number you�ve entered" 
//		+ "doesn�t match any account. Sign up for an account.");
//	
	
	
	
	//########### Verification ############
	
	try {
		assertEquals(driver.getTitle(), expectedTitle);
	} catch (Exception e) {
		e.printStackTrace(); 
	}
	
	
	//close the browser
	driver.close();
				
				

	}

}