package TestAutomation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class OpenBrowser {

	public static void main(String[] args) {
		
		//Create instance of WebDriver
		WebDriver driver = new FirefoxDriver();
		
		//Open url into browser
		driver.get("http://newtours.demoaut.com/");
		
				
		//close the browser
		driver.close();
		
		//close webdriver
		driver.quit();
		
	}

}
