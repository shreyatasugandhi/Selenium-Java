package TestAutomation;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Locators3 {

	public static void main(String[] args) {

		//set system property
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//Initiate Chrome driver
		WebDriver driver = new ChromeDriver();
	
		//navigate facebok page
		driver.navigate().to("https://www.facebook.com/");
		
		
		////#####  XPATH ####/////
		////#####  xpath ####/////

		
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys("shreyata.sugandhi");
		
		//Using xpath - with tagname and attribute
		driver.findElement(By.xpath(".//input[@name='firstname']")).sendKeys("Shreyata");


		//xpath with value
		driver.findElement(By.xpath(".//*[@value='Log In']")).click();
		
		// navigating back to the home page
		driver.navigate().back();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				


			
		//xpath with contains
		driver.findElement(By.xpath("//a[contains(text(), 'Forgotten')]")).click();
		
		// navigating back to the home page
		driver.navigate().back();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath(".//button[contains(text(), 'Up')]")).click();

				
		//xpath with contains for imgs
		driver.findElement(By.xpath("//img[contains(@src,'OBaVg52wtTZ.png')]")).click();


//		//xpath with value for radio button
//		driver.findElement(By.xpath(".//*[@value='1']")).click();
//
//		
//		//xpath with select for select box
//		new Select(driver.findElement(By.xpath("//select[@aria-label='Day']"))).selectByVisibleText("5");
//
//		
//		//xpath with OR & AND
//		driver.findElement(By.xpath(".//*[@type='password' and @name='pass']")).sendKeys("password");
//		driver.findElement(By.xpath("//input[@id='pass' or @name='pass']")).sendKeys("shreyata");
//		
//		//xpath with following
//		driver.findElement(By.xpath("//div[contains(text(),'First name')]//following::input[1]")).sendKeys("shreyata");
//
//		//xpath with preceding
//		driver.findElement(By.xpath("//div[contains(text(),'Surname')]//preceding::input[1]")).sendKeys("shreyata");
//		
//		//xpath with following-sibling
//		driver.findElement(By.xpath("//select[@id='day']//following-sibling::select[1]")).sendKeys("shreyata");
//		
//		//xpath with preceding-sibling
//		driver.findElement(By.xpath("//label[contains(text(),'Female')]//preceding-sibling::input")).sendKeys("shreyata");
//		
//		//xpath with parent
//		driver.findElement(By.xpath("//input[@id='u_0_6']//parent::span//following-sibling::span[1]/input")).sendKeys("shreyata");


		
	}

}
