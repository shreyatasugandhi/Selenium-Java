package TestAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Locators3 {

	public static void main(String[] args) {

		// initiate webdriver
		WebDriver driver = new FirefoxDriver();
		
		
		//open url
		driver.get("http://newtours.demoaut.com/");
		
		//Login
		driver.findElement(By.name("userName")).clear();
	    driver.findElement(By.name("userName")).sendKeys("tutorial");
	    
	    driver.findElement(By.name("password")).clear();
	    driver.findElement(By.name("password")).sendKeys("tutorial");

	    driver.findElement(By.name("login")).click();
		
	    
	    ///// Find by xpath
		//Click on a round trip radio button
		driver.findElement(By.xpath(".//*[@value='roundtrip']")).click();
		
		
	}

}
