package TestAutomation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class WorkingWithMultipleBrowser {

	public static void main(String[] args) throws Exception {
		
		//Declare webdriver 
		WebDriver driver;
		
		 String browser = "firefox";
	        
		
		//Check if broser = 'firefox'
       if(browser.equalsIgnoreCase("firefox")){
    	   
//    	   ProfilesIni profile = new ProfilesIni();
//    	   FirefoxProfile myprofile = profile.getProfile("SeleniumffP");
//    	   //WebDriver driver = new FirefoxDriver(myprofile);
//    	   
//    	   FirefoxProfile ffprofile = new FirefoxProfile();
//    	   ffprofile.setPreference("browser.startup.homepage","http://www.google.com");
//    	   driver = new FirefoxDriver(ffprofile);
    	   
    	   System.setProperty("webdriver.gecko.driver", "C:\\SeleniumWebdrivers\\geckodriver.exe");
    	   
    	   
    	   
    	   //create firefox instance
           driver = new FirefoxDriver();
           
        }

        //Check if browser = 'chrome'
        else if(browser.equalsIgnoreCase("chrome")){
        	
            //set path to chromedriver.exe You may need to download it from http://code.google.com/p/selenium/wiki/ChromeDriver
//    		String service = "C:\\SeleniumDrivers\\chromedriver.exe";
//    		System.setProperty("webdriver.chrome.driver", service);

            //create chrome instance
            driver = new ChromeDriver();
            
        }
       
       //Check if browser = 'ie'
        else if(browser.equalsIgnoreCase("ie")){
//        	String service = "D:\\Softwares\\Selenium\\SeleniumDrivers\\IEDriverServer.exe";
//        	System.setProperty("webdriver.ie.driver", service);

        	//create IE instance
        	driver = new InternetExplorerDriver();
        	
        }
       
       //If no browser declared then
        else{
            throw new Exception("Browser is not declared");
        }

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
     // open url
     driver.get("http://newtours.demoaut.com/");
    
     String title = driver.getTitle();
     System.out.println(title);
     
     //Close browser
     driver.quit();
     

	}

}
