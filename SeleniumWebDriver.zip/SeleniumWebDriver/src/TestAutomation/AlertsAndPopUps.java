package TestAutomation;

import java.util.concurrent.TimeUnit;
import static org.testng.Assert.*;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AlertsAndPopUps {
	public static void main(String[] args) {
		
		//initiate webdriver
		WebDriver driver = new FirefoxDriver();
		
		//maximize window
		driver.manage().window().maximize();
		
		//implicit wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//open url
		driver.get("http://the-internet.herokuapp.com/javascript_alerts");
		
		
		
		
		//########### JavaScript Alert ########//
		
		// This step will result in an alert on screen
		driver.findElement(By.xpath(".//button[contains(text(), 'Click for JS Alert')]")).click();
		
		Alert simpleAlert = driver.switchTo().alert();
		String alertText = simpleAlert.getText();
		System.out.println("Alert text is " + alertText);
		simpleAlert.accept();
		assertEquals(driver.findElement(By.id("result")).getText(), "You successfuly clicked an alert");
	
		
		
		
		
		//####### Confirmation popup ##### //
		
		// This step will result in an alert on screen
		WebElement element = driver.findElement(By.xpath(".//button[@onclick='jsConfirm()']"));
		element.click();
		
		Alert confirmationAlert = driver.switchTo().alert();
		String confirmationText = confirmationAlert.getText();
		System.out.println("Alert text is " + confirmationText);
		//click OK button on the confirmation box
		confirmationAlert.accept();
		assertEquals(driver.findElement(By.id("result")).getText(), "You clicked: Ok");
		System.out.println(driver.findElement(By.id("result")).getText());
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		element.click();
		Alert confirmationAlert2 = driver.switchTo().alert();
		//click Cancel button on the confirmation box
		confirmationAlert2.dismiss();
		assertEquals(driver.findElement(By.id("result")).getText(), "You clicked: Cancel");
		System.out.println(driver.findElement(By.id("result")).getText());
		
	
		
		//####### Prompts ######//
		
		driver.findElement(By.xpath(".//button[@onclick='jsPrompt()']")).click();
		Alert prompt = driver.switchTo().alert();
		prompt.sendKeys("Helllo");
		prompt.accept();
		System.out.println(prompt.getText());
		assertEquals(driver.findElement(By.id("result")).getText(), "You entered: Hello");
		
		
		
		driver.quit();
	
	}

}
