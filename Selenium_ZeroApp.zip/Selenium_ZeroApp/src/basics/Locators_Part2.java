package basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locators_Part2 {

	public static void main(String[] args) {
		
		// set system property
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//create driver instance
		WebDriver driver = new ChromeDriver();
		
		
		//open browser and open url
		driver.get("http://zero.webappsecurity.com/index.html");
		

		// CSS Selector techniques
		
		//// Find by css = #id
		//Enter login name
		driver.findElement(By.cssSelector("#user_login")).sendKeys("username");
		
		
		/// Find by css = tag#id
		//Enter Password
		driver.findElement(By.cssSelector("input#user_password")).sendKeys("password");
		
						
		
		//// Find by css=tag.class
		//type in search box
		driver.findElement(By.cssSelector("input.search-query")).sendKeys("text");
		
		
		//// Find by css=tag[attribute='value']
		//type in search box
		driver.findElement(By.cssSelector("input[placeholder='Search']")).sendKeys("text");		
		
			
		//// Find by css=tag.class[attribute='value']
		driver.findElement(By.cssSelector("input.search-query[placeholder='Search']")).sendKeys("text");
		
		
		
		//close browser
		driver.close();
		
		//close driver
		driver.quit();



	}

}
