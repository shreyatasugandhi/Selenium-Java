package basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locators_part1 {

	public static void main(String[] args) {

		// set system property
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//create driver instance
		WebDriver driver = new ChromeDriver();
		
		
		//open browser and open url
		driver.get("http://zero.webappsecurity.com/index.html");
		
		//type into search box
		driver.findElement(By.className("search-query")).sendKeys("Online Banking");
		
		// Click on sign in button
		driver.findElement(By.id("signin_button")).click();
		
		//Enter username
		driver.findElement(By.name("user_login")).sendKeys("username");
		
		//Enter password
		driver.findElement(By.name("user_password")).sendKeys("password");
			
		//LinkText - click on "Forgot your password ?" link	
		driver.findElement(By.linkText("Forgot your password ?")).click();		
		
		//partial LinkText - click on "Forgot your password ?" link	
		driver.findElement(By.partialLinkText("Forgot your password")).click();		

		
		//Click on sign in button
		//driver.findElement(By.name("submit")).click();	
		
		
		//close browser
		driver.close();
		
		//close driver
		driver.quit();

	}

}
