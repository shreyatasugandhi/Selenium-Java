package basics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class OpenAndCloseBrowser {

	public static void main(String[] args) {
		
		// set system property
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//create driver instance
		WebDriver driver = new ChromeDriver();
		
		
		//open browser and open url
		driver.get("http://zero.webappsecurity.com/index.html");
		
			
		
		//close browser
		driver.close();
		
		//close driver
		driver.quit();

	}

}
