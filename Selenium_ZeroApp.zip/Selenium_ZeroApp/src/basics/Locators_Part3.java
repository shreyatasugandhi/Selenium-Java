package basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Locators_Part3 {

	public static void main(String[] args) {
		// set system property
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//create driver instance
		WebDriver driver = new ChromeDriver();
		
		
		//open browser and open url
		driver.get("http://newtours.demoaut.com/mercuryregister.php");
		
		///working with Selectbox	
		Select country = new Select(driver.findElement(By.name("country")));
		country.selectByValue("235");
		country.selectByVisibleText("ARUBA ");
		
		//radio button selection
		//driver.findElement(By.name("inDollars")).click();
		driver.findElement(By.cssSelector("input#pc_inDollars_false")).click();
		
		
		
		//close browser
		driver.close();
		
		//close driver
		driver.quit();

		
		
	}

}
